import React from 'react'
import { StyleSheet, Text, View, Button } from 'react-native'

const GitScreen = ({navigation}) => {
    return (
        <View style={styles.container}>
            <Text>Git Screen</Text>
            <Button 
                title="Vamos a la pantalla detalle" 
                onPress={()=>navigation.navigate('DetailsScreen',{nombre:'@pedroesquerra'})}
            />
        </View>
    )
}

export default GitScreen

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'space-around',
    },
});